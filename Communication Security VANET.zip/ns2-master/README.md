##### Each folder has a README.md in it. Go through it for further implementation details.

##### Hit the `Star` button on the top-right if you like it :stuck_out_tongue:
